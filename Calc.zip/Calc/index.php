<?php
$var1 = 0;
$var2 = 0;
$result = 0;
$calc = "calc";

if(isset ($_POST["sum"])){
    $var1 = (int)$_POST['var1'];
    $var2 = (int)$_POST['var2'];
    $calc = $_POST['sum'];
    $result = $var1 + $var2;
}
else
if(isset ($_POST["minus"])){
    $var1 = (int)$_POST['var1'];
    $var2 = (int)$_POST['var2'];
    $calc = $_POST['minus'];
    $result = $var1 - $var2;
}
else
if(isset ($_POST["multi"])){
    $var1 = (int)$_POST['var1'];
    $var2 = (int)$_POST['var2'];
    $calc = $_POST['multi'];
    $result = $var1 * $var2;
}
else
if(isset ($_POST["div"])){
    $var1 = (int)$_POST['var1'];
    $var2 = (int)$_POST['var2'];
    $calc = $_POST['div'];
    $result = $var1 / $var2;
}


?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    
    <form method="post">
        Primeiro numero <br>
        <input type="number" name="var1" value= <?= $var1 ?> required > <br>
        Segundo numero  <br>
        <input type="number" name="var2" value= <?= $var2 ?> required  > <br>
        <input type="submit" name="sum" value="+">
        <input type="submit" name="minus" value="-">
        <input type="submit" name="multi" value="*">
        <input type="submit" name="div" value="/">
        <br><br>
        
        <p>Resultado da soma: <?= $result ?> </p>
    </form>

</body>
</html>
