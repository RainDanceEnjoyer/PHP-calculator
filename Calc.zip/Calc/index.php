<?php
$var1 = 0;
$var2 = 0;
$result = 0;
$calc = "calc";

if(isset ($_POST["sum"])){
    $var1 = (int)$_POST['var1'];
    $var2 = (int)$_POST['var2'];
    $calc = $_POST['sum'];
    $result = $var1 + $var2;
}
else
if(isset ($_POST["minus"])){
    $var1 = (int)$_POST['var1'];
    $var2 = (int)$_POST['var2'];
    $calc = $_POST['minus'];
    $result = $var1 - $var2;
}
else
if(isset ($_POST["multi"])){
    $var1 = (int)$_POST['var1'];
    $var2 = (int)$_POST['var2'];
    $calc = $_POST['multi'];
    $result = $var1 * $var2;
}
else
if(isset ($_POST["div"])){
    $var1 = (int)$_POST['var1'];
    $var2 = (int)$_POST['var2'];
    $calc = $_POST['div'];
    $result = $var1 / $var2;
}


?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<body id="bodyfix"class="text-white">
    <div class="position-absolute start-50 top-50 translate-middle">
    <form method="post" id="fix" class="border shadow-lg">  
        <div class="m-3">
        Primeiro numero <br>
        <input class="rounded" type="number" name="var1" value= <?= $var1 ?> required > <br>
        Segundo numero  <br>
        <input class="rounded" type="number" name="var2" value= <?= $var2 ?> required  > <br>
        <div class="text-center mt-5">
        <input class="m-1 bg-white btn btn-primary btn-lg text-dark" type="submit" name="sum" value="+">
        <input class="m-1 bg-white btn btn-primary btn-lg text-dark" type="submit" name="minus" value="- "><br>
        <input class="m-1 bg-white btn btn-primary btn-lg text-dark" type="submit" name="multi" value="* ">
        <input class="m-1 bg-white btn btn-primary btn-lg text-dark" type="submit" name="div" value="/ "></div>
       
        <br><br>
        
        <p>Resultado da soma: <?= $result ?> </p>
        </div>
       
    </div>

    <img src="transrights.png" width="10vw" height="6.5vw">
    <style>
#fix{
    background-color: #F8BBD0;
}
#bodyfix{
    background-color: #64B5F6;
}
        </style>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    </form>

</body>
</html>
